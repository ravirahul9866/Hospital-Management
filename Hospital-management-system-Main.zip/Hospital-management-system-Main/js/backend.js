function  sanju(){
  alert("The payment is processing");
  open("html/index.html");

}
<input type="button" value="ok" onclick="sanju()" >
